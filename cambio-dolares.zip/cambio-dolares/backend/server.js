const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
require('dotenv').config();

const db = require('./database');
const ratesRoutes = require('./routes/rates');
const transactionsRoutes = require('./routes/transactions');
const summaryRoutes = require('./routes/summary');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Rutas
app.use('/api/rates', ratesRoutes);
app.use('/api/transactions', transactionsRoutes);
app.use('/api/summary', summaryRoutes);

// Servir frontend estático
app.use(express.static('../frontend'));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
