const express = require('express');
const db = require('../database');
const router = express.Router();

// Registrar transacción
router.post('/', (req, res) => {
    const { type, amount_usd, rate } = req.body;
    db.run('INSERT INTO transactions (type, amount_usd, rate) VALUES (?, ?, ?)', [type, amount_usd, rate], function(err) {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ success: true, id: this.lastID });
    });
});

// Obtener transacciones del día
router.get('/', (req, res) => {
    db.all('SELECT * FROM transactions ORDER BY created_at DESC', (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
});

module.exports = router;
