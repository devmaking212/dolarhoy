const express = require('express');
const db = require('../database');
const router = express.Router();

// Obtener última tasa
router.get('/latest', (req, res) => {
    db.get('SELECT * FROM rates ORDER BY updated_at DESC LIMIT 1', (err, row) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(row || { buy_rate: 0, sell_rate: 0 });
    });
});

// Actualizar tasa
router.post('/', (req, res) => {
    const { buy_rate, sell_rate } = req.body;
    db.run('INSERT INTO rates (buy_rate, sell_rate) VALUES (?, ?)', [buy_rate, sell_rate], function(err) {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ success: true, id: this.lastID });
    });
});

module.exports = router;
